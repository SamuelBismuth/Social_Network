var searchData=
[
  ['chana',['chana',['../main_8cpp.html#afb11124f59f02b4fa24aba3ec7315594',1,'main.cpp']]]
];
