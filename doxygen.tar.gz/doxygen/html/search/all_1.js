var searchData=
[
  ['beni',['beni',['../main_8cpp.html#a79cc13221c36036ba5e553fed5c32b7f',1,'main.cpp']]]
];
