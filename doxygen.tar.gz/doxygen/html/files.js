var files =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Member.cpp", "_member_8cpp.html", null ],
    [ "Member.h", "_member_8h.html", [
      [ "Member", "class_member.html", "class_member" ]
    ] ]
];